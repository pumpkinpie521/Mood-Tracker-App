import SwiftUI

struct Mood: Identifiable {
    let id = UUID()
    let emoji: String
    let description: String
    let date: Date
}

struct ContentView: View {
    @State private var moods: [Mood] = []
    @State private var todayMood: Mood?
    
    // List of possible moods
    let moodOptions: [(emoji: String, description: String)] = [
        ("😊", "Happy"),
        ("😐", "Okay"),
        ("😔", "Sad"),
        ("😡", "Angry"),
        ("😴", "Tired")
    ]
    
    var body: some View {
        ZStack {
            Color(.systemTeal)
                .ignoresSafeArea()
            
            VStack(spacing: 30) {
                Text("Mood Tracker 🌤️")
                    .font(.largeTitle)
                    .foregroundColor(.white)
                    .padding(.top, 50)
                
                // Today’s Mood Display
                if let mood = todayMood {
                    VStack {
                        Text("Today's Mood")
                            .font(.title2)
                            .foregroundColor(.white)
                        Text("\(mood.emoji) \(mood.description)")
                            .font(.largeTitle)
                            .padding()
                    }
                } else {
                    Text("Tap a mood to get started!")
                        .font(.title2)
                        .foregroundColor(.white)
                }
                
                // Mood Buttons
                HStack(spacing: 15) {
                    ForEach(moodOptions, id: \.description) { option in
                        Button(action: {
                            let newMood = Mood(emoji: option.emoji, description: option.description, date: Date())
                            todayMood = newMood
                            moods.insert(newMood, at: 0)
                        }) {
                            Text(option.emoji)
                                .font(.largeTitle)
                                .frame(width: 60, height: 60)
                                .background(Color.white.opacity(0.3))
                                .cornerRadius(15)
                        }
                    }
                }
                
                // Recent Moods
                VStack(alignment: .leading, spacing: 5) {
                    Text("Recent Moods:")
                        .font(.title3)
                        .foregroundColor(.white)
                        .padding(.top, 20)
                    ForEach(moods.prefix(5)) { mood in
                        HStack {
                            Text(mood.emoji)
                            Text(mood.description)
                            Spacer()
                            Text("\(mood.date, formatter: dateFormatter)")
                                .font(.caption)
                        }
                        .foregroundColor(.white)
                    }
                }
                .padding(.horizontal, 30)
                
                Spacer()
            }
        }
    }
    
    // Date formatter for history
    private var dateFormatter: DateFormatter {
        let formatter = DateFormatter()
        formatter.dateStyle = .short
        formatter.timeStyle = .short
        return formatter
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
